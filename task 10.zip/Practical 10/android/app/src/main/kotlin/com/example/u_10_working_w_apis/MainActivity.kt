package com.example.u_10_working_w_apis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
